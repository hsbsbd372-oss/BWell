# B-WELL (Android-first, Phase 1: dummy data)

Native Android app: Kotlin, Jetpack Compose, MVVM, Room. No network permission. No real accounts.

## Using the app vs compiling it
- **Using** B-WELL = installing the APK on your phone.
- **Compiling** = turning this source into an APK. Your phone does not do this; GitHub's cloud servers do.

## Phone-only workflow
1. Create a free GitHub account (phone browser or the GitHub app) and a **private** repository.
2. Upload this project's files to it (GitHub web "Add file > Upload files"; keep the `.github/workflows` folder).
3. Repo > Actions > "Build debug APK" > Run workflow. Takes a few minutes.
4. Open the finished run, download the `bwell-debug-apk` artifact (a zip), extract it with your phone's Files app.
5. Compare the SHA-256 in `SHA256.txt` with the APK (any hash-checker app) if you want to confirm integrity.
6. Open the APK. Android will ask you to allow installs from that app (Files/Chrome). Allow once, install, then turn the permission back off.
7. Updates: re-run the workflow and install the new APK over the old one (same debug key keeps your data only if the signing key matches; debug keys on CI can change, so early on expect to reinstall).

Never put API keys, keystores, or passwords in the repo. Later signing keys go in GitHub encrypted secrets.

## Docs
- `docs/SECURITY_ASSESSMENT.md`: what is collected, where it goes, what is tested (currently nothing), known gaps.

## Roadmap (each item done only when implemented, tested, documented)
1. Phase 1: dashboard, tasks, reminders (local notifications), dummy data. <- here (scaffold, unbuilt)
2. DB encryption + app lock + security tests T1-T6.
3. Release signing, update flow.
4. Voice (on-device recognition, push-to-talk only).
5. Gmail/Calendar (read-only first), only after your explicit approval.
6. Notification listener, per-app allow-list, only after your explicit approval.
