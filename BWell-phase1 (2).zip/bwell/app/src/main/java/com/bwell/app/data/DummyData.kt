package com.bwell.app.data

import java.time.LocalDate

/** Everything in this file is FAKE. No real people, accounts, or messages. */
data class DummyEmail(val from: String, val subject: String, val preview: String, val unread: Boolean, val important: Boolean)
data class DummyMessage(val app: String, val from: String, val text: String)
data class DummyEvent(val time: String, val title: String)
data class DummyContact(val name: String, val note: String)
data class DummyNotification(val app: String, val title: String, val important: Boolean)

object DummyData {
    val emails = listOf(
        DummyEmail("Test Sender A", "Project update due Friday", "Please review the sample document (fake).", true, true),
        DummyEmail("Test Newsletter", "Weekly digest", "Fake newsletter content.", true, false),
        DummyEmail("Test Sender B", "Meeting notes", "Sample notes for testing.", false, false),
    )
    val messages = listOf(
        DummyMessage("TestChat", "Alex Example", "Are we still on for tomorrow? (fake)"),
        DummyMessage("TestChat", "Sam Sample", "Sent you the file. (fake)"),
    )
    val events = listOf(
        DummyEvent("09:30", "Stand-up (fake)"),
        DummyEvent("13:00", "Study block (fake)"),
        DummyEvent("18:00", "Workout (fake)"),
    )
    val contacts = listOf(
        DummyContact("Alex Example", "Test contact"),
        DummyContact("Sam Sample", "Test contact"),
    )
    val notifications = listOf(
        DummyNotification("TestChat", "New message from Alex Example", true),
        DummyNotification("TestMail", "2 new emails", false),
    )

    val seedTasks: List<TaskEntity>
        get() {
            val today = LocalDate.now().toEpochDay()
            return listOf(
                TaskEntity(title = "Review sample document", dueEpochDay = today + 2),
                TaskEntity(title = "Plan the week", dueEpochDay = today),
                TaskEntity(title = "Try adding your own task", dueEpochDay = null),
            )
        }
}
