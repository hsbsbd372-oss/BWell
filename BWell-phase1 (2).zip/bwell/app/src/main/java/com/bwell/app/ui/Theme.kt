package com.bwell.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Scheme = darkColorScheme(
    primary = Color(0xFF4DD0E1),
    secondary = Color(0xFF9C7BFF),
    background = Color(0xFF0B0F1A),
    surface = Color(0xFF131A2A),
    surfaceVariant = Color(0xFF1B2438),
    onPrimary = Color(0xFF00252B),
    onBackground = Color(0xFFE6ECF5),
    onSurface = Color(0xFFE6ECF5),
)

@Composable
fun BWellTheme(content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = Scheme, content = content)
