package com.bwell.app

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.bwell.app.data.AppDb
import com.bwell.app.data.DummyData
import com.bwell.app.data.TaskEntity
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).tasks()
    private val prefs = app.getSharedPreferences("bwell_prefs", Context.MODE_PRIVATE)

    val tasks: StateFlow<List<TaskEntity>> =
        dao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    // Display name is a non-sensitive preference chosen by the user.
    private val _name = MutableStateFlow(prefs.getString("name", "Friend") ?: "Friend")
    val name: StateFlow<String> = _name

    init {
        viewModelScope.launch {
            if (!prefs.getBoolean("seeded", false)) {
                DummyData.seedTasks.forEach { dao.insert(it) }
                prefs.edit().putBoolean("seeded", true).apply()
            }
        }
    }

    fun setName(value: String) {
        val clean = value.trim().take(40).ifEmpty { "Friend" }
        _name.value = clean
        prefs.edit().putString("name", clean).apply()
    }

    fun addTask(title: String) {
        val clean = title.trim().take(200)
        if (clean.isNotEmpty()) viewModelScope.launch { dao.insert(TaskEntity(title = clean)) }
    }

    fun toggle(task: TaskEntity) {
        viewModelScope.launch { dao.update(task.copy(done = !task.done)) }
    }

    /** Deletes every task and resets preferences. Real "delete my data" for Phase 1. */
    fun wipeAllData() {
        viewModelScope.launch {
            dao.deleteAll()
            prefs.edit().clear().apply()
            _name.value = "Friend"
        }
    }

    fun todayEpochDay(): Long = LocalDate.now().toEpochDay()
}
