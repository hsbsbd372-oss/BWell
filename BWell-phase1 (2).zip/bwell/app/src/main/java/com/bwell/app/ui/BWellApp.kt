package com.bwell.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.bwell.app.MainViewModel
import com.bwell.app.data.DummyData
import kotlinx.coroutines.launch
import java.time.LocalDate

enum class Screen(val label: String) {
    Home("Home"), Assistant("AI Assistant"), Emails("Emails"), Messages("Messages"),
    Tasks("Tasks"), Calendar("Calendar"), Deadlines("Deadlines"), Contacts("Contacts"),
    Notifications("Notifications"), Settings("Settings")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BWellApp(vm: MainViewModel) {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var current by remember { mutableStateOf(Screen.Home) }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Text("B-WELL", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(20.dp))
                Screen.entries.forEach { s ->
                    NavigationDrawerItem(
                        label = { Text(s.label) },
                        selected = s == current,
                        onClick = { current = s; scope.launch { drawerState.close() } },
                        modifier = Modifier.padding(horizontal = 12.dp),
                    )
                }
            }
        },
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(current.label) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "Open menu")
                        }
                    },
                )
            },
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                DummyBanner()
                when (current) {
                    Screen.Home -> HomeScreen(vm)
                    Screen.Assistant -> Placeholder("Voice and AI assistant arrive in a later phase. Nothing is recorded or sent anywhere now.")
                    Screen.Emails -> EmailsScreen()
                    Screen.Messages -> MessagesScreen()
                    Screen.Tasks -> TasksScreen(vm)
                    Screen.Calendar -> CalendarScreen()
                    Screen.Deadlines -> DeadlinesScreen(vm)
                    Screen.Contacts -> ContactsScreen()
                    Screen.Notifications -> NotificationsScreen()
                    Screen.Settings -> SettingsScreen(vm)
                }
            }
        }
    }
}

@Composable
private fun DummyBanner() {
    Surface(color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.25f), modifier = Modifier.fillMaxWidth()) {
        Text(
            "TEST MODE: dummy data only. No real accounts connected. No internet permission.",
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
        )
    }
}

@Composable
private fun CardRow(title: String, subtitle: String? = null, trailing: @Composable (() -> Unit)? = null) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodyMedium)
            }
            trailing?.invoke()
        }
    }
}

@Composable
private fun Placeholder(text: String) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Text(text, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun HomeScreen(vm: MainViewModel) {
    val name by vm.name.collectAsStateWithLifecycle()
    val tasks by vm.tasks.collectAsStateWithLifecycle()
    val pending = tasks.count { !it.done }
    val today = LocalDate.now().toEpochDay()
    val soon = tasks.count { !it.done && it.dueEpochDay != null && it.dueEpochDay <= today + 3 }
    val doneCount = tasks.count { it.done }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 8.dp)) {
        item { CardRow("Hello, $name", "B-WELL status: test mode (offline, dummy data)") }
        item {
            CardRow("Voice assistant", "Not enabled yet. No microphone permission requested.") {
                Button(onClick = {}, enabled = false) { Text("Talk") }
            }
        }
        item { CardRow("Unread emails (dummy)", "${DummyData.emails.count { it.unread }}") }
        item { CardRow("Important notifications (dummy)", "${DummyData.notifications.count { it.important }}") }
        item { CardRow("Pending tasks", "$pending") }
        item { CardRow("Deadlines in next 3 days", "$soon") }
        item { CardRow("Today's schedule (dummy)", DummyData.events.joinToString("\n") { "${it.time}  ${it.title}" }) }
        item { CardRow("Productivity summary", "$doneCount done, $pending pending") }
    }
}

@Composable private fun EmailsScreen() = LazyColumn {
    items(DummyData.emails) { CardRow((if (it.important) "★ " else "") + it.subject, "${it.from}: ${it.preview}") }
}

@Composable private fun MessagesScreen() = LazyColumn {
    items(DummyData.messages) { CardRow(it.from, "${it.app}: ${it.text}") }
}

@Composable private fun CalendarScreen() = LazyColumn {
    items(DummyData.events) { CardRow(it.title, it.time) }
}

@Composable private fun ContactsScreen() = LazyColumn {
    items(DummyData.contacts) { CardRow(it.name, it.note) }
}

@Composable private fun NotificationsScreen() = LazyColumn {
    items(DummyData.notifications) { CardRow(it.title, it.app + if (it.important) " (important)" else "") }
}

@Composable
private fun TasksScreen(vm: MainViewModel) {
    val tasks by vm.tasks.collectAsStateWithLifecycle()
    var text by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(text, { text = it }, label = { Text("New task") }, singleLine = true, modifier = Modifier.weight(1f))
            Spacer(Modifier.width(8.dp))
            Button(onClick = { vm.addTask(text); text = "" }) { Text("Add") }
        }
        LazyColumn {
            items(tasks, key = { it.id }) { t ->
                CardRow(t.title, t.dueEpochDay?.let { "Due ${LocalDate.ofEpochDay(it)}" }) {
                    Checkbox(checked = t.done, onCheckedChange = { vm.toggle(t) })
                }
            }
        }
    }
}

@Composable
private fun DeadlinesScreen(vm: MainViewModel) {
    val tasks by vm.tasks.collectAsStateWithLifecycle()
    val withDue = tasks.filter { !it.done && it.dueEpochDay != null }.sortedBy { it.dueEpochDay }
    if (withDue.isEmpty()) Placeholder("No upcoming deadlines.")
    else LazyColumn { items(withDue, key = { it.id }) { CardRow(it.title, "Due ${LocalDate.ofEpochDay(it.dueEpochDay!!)}") } }
}

@Composable
private fun SettingsScreen(vm: MainViewModel) {
    val name by vm.name.collectAsStateWithLifecycle()
    var field by remember(name) { mutableStateOf(name) }
    var confirm by remember { mutableStateOf(false) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            OutlinedTextField(field, { field = it }, label = { Text("Your name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Button(onClick = { vm.setName(field) }, modifier = Modifier.padding(top = 8.dp)) { Text("Save name") }
        }
        item {
            Text("Real integrations", style = MaterialTheme.typography.titleMedium)
            Text("Gmail, Calendar, notification access, voice, and AI: LOCKED. They are not built or enabled, and will stay locked until you approve them after the security assessment.")
        }
        item {
            Text("Your data", style = MaterialTheme.typography.titleMedium)
            Text("Everything lives in this app's private storage on this phone. Nothing is uploaded. Cloud backup is disabled.")
            Button(onClick = { confirm = true }, modifier = Modifier.padding(top = 8.dp)) { Text("Delete all my data") }
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Delete all data?") },
        text = { Text("This removes all tasks and settings from this phone. It cannot be undone.") },
        confirmButton = { TextButton(onClick = { vm.wipeAllData(); confirm = false }) { Text("Delete") } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
    )
}
