# B-WELL Security Assessment: Phase 1 (dummy data)

Status date: 2026-11-18. Version 0.1.0-phase1-dummy.

**B-WELL is NOT claimed to be secure.** Nothing below has been tested yet. Statements
are labelled VERIFIED (checked by a tool/test, with evidence), BY DESIGN (true of the
code as written, but not yet tested), or PLANNED. At this point there are no VERIFIED items.

Real account access: **DISABLED. Will not be enabled without your explicit approval.**

## 1. Source code
Complete Phase 1 source is in this project. It has **not been compiled or run** yet
(the authoring workspace had no Android SDK). First cloud build is the first real test.

## 2. Data collected (Phase 1)
| Data | Source | Real or fake |
|---|---|---|
| Tasks you type | You | Real (your input) |
| Display name | You | Real (your input) |
| Emails, messages, events, contacts, notifications | Built into the app | FAKE |

No analytics, crash reports, device IDs, location, contacts, or usage telemetry are collected. BY DESIGN.

## 3. External servers receiving data
**None.** The app declares no INTERNET permission, so Android blocks all its network access. BY DESIGN
(to be VERIFIED by inspecting the built APK's merged manifest, see test T1).
Note: the build process itself talks to GitHub, Google Maven, and Maven Central to download
build tools. That is the build machine, not the app.

## 4. Third-party services and AI providers
**None in the app.** Libraries compiled in: AndroidX (Compose, Room, Lifecycle, Activity),
Kotlin standard library. No AI provider is selected. Choosing one (and what it would see)
is a decision for the real-integration phase and needs your approval.

## 5. Where data is stored
App-private storage on your phone only: a Room (SQLite) database `bwell.db` and one
SharedPreferences file. Cloud backup and device-to-device transfer are disabled in the
manifest. BY DESIGN. **The database is NOT encrypted in Phase 1** (see 9).

## 6. Encryption and authentication
- At rest: none beyond Android's own app sandbox and device encryption. PLANNED: encrypted DB with a key held in Android Keystore, required before any real data.
- In transit: not applicable (no network). Cleartext traffic is also disabled in the manifest.
- Authentication: none. No accounts exist. PLANNED: Google OAuth 2.0 with minimal scopes, later, with your approval.
- App lock (biometric/PIN): not built. Anyone who unlocks your phone can open B-WELL.

## 7. Permissions
Declared permissions: **none.** No internet, notifications access, microphone, contacts,
calendar, storage, or foreground service.
Future permissions will each be listed here, with reason, before being added:
INTERNET (Gmail/Calendar/AI), notification listener (user-granted in system settings),
RECORD_AUDIO, POST_NOTIFICATIONS.

## 8. Security testing results
**None run yet.** Planned for the first successful build:
- T1 Inspect built APK merged manifest: confirm zero permissions (aapt2 / apkanalyzer).
- T2 Confirm backup disabled (manifest + `adb shell dumpsys` on a test device).
- T3 Confirm DB readable only by the app (not exported provider/activities beyond launcher).
- T4 Static analysis (Android Lint security checks; later MobSF).
- T5 Dependency vulnerability scan.
- T6 Confirm "Delete all my data" actually empties the DB and prefs.
Results will be recorded here with date, tool, and output. Failures stay in this file.

## 9. Known vulnerabilities and limitations
- DB unencrypted (acceptable only because data is dummy or trivial; blocking for real data).
- No app lock.
- Gradle/library versions were written from memory and unverified for currency or known CVEs.
- GitHub Actions are referenced by version tag, not commit SHA (supply-chain hardening pending).
- Debug APK is debuggable and signed with a debug key: for testing only.
- Export of your data is not implemented yet (delete is).
- Release signing, update mechanism, and AAB are not built.
- Not yet built or run: bugs are likely.

## 10. Independent security audit
**None exists.** This project has had no independent review. Do not treat any statement
here as an audit. An external review should be considered before real accounts are connected.

## Gate before real integrations
Real Gmail/Calendar/notification/voice/AI access stays off until: DB encryption is
implemented and tested; tests T1-T6 pass with recorded evidence; you have reviewed items 2-7
for the specific integration (what is sent, to whom, what is stored); and you say yes.
